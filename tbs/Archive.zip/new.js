$('.slidercontainertestimonials').slick({
	slidesToShow: 1,
	sliesToScroll: 1,
	inifinte: false,
	centerMode: false
})