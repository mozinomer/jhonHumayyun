$('.sliderContainershop').slick({
	slidesToShow: 3,
	arrows: true,
	dots: false,
})